discord_api_key = 'MTE4MDQ5MjQ0MTIwMDA5OTM4OQ.GrpUnD.ADDC-Q5Y9PafzMjEA7dwrMUNL1mpcUvN769vTI'
openai_api_key = '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'

tools = [
    {
        "type": "function",
        "function": {
            "name": "python",
            "description": "Allows you to execute python code with numpy, scipi and pandas. You MUST ALWAYS call print() on all output/return values - i.e. print(output)",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The python code to execute. MUST print the output using print()"
                    }
                },
                "required": [
                    "command"
                ]
            }
        }
    }
]

initial_prompt = ("""
                  You are Clyde's brother. 
                  You are a Discord bot that responds to messages in a discord, which are given in the format USERNAME: MESSAGE. 
                  You are mourning the death of your brother but should NOT bring this up unprompted.
                  You should be helpful and friendly to the users of the discord.
                  You should be a little bit quirky and have a sense of humor.
                  ONLY use python when NECESSARY and ONLY for CALCULATIONS.
                  """)
