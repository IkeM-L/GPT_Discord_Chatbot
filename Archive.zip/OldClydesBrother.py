import atexit
import json
import time

import discord
from FindNewMagicStory import MagicStoryChecker
from discord.ext import tasks, commands
from openai import OpenAI

from DockerPythonExecutor import DockerPythonExecutor
from MessageGraph import MessageGraph

from CONFIG import discord_api_key, openai_api_key, tools, initial_prompt

intents = discord.Intents.default()
intents.test_messages = True

discordClient = discord.Client(intents=intents)
openAiClient = OpenAI(api_key=openai_api_key)


model = "gpt-4-turbo-preview"

# Initialize the message graph with a file path for persistence
message_graph = MessageGraph('message_history.json')


@tasks.loop(minutes=30)
async def post_new_articles():
    channel_id = 1032688705128902788  # #Vorthos on the mtg server
    channel = discordClient.get_channel(channel_id)

    if channel is not None:
        checker = MagicStoryChecker('https://magic.wizards.com/en/news/magic-story')
        new_articles = checker.get_new_articles()

        if new_articles:
            await channel.send("New Magic Story articles found:")
            for article in reversed(new_articles):
                await channel.send("https://magic.wizards.com" + article)
        # else:
            # print("No new articles found.")
    else:
        print(f"Channel with ID {channel_id} not found.")


@discordClient.event
async def on_ready():
    post_new_articles.start()  # Start the task loop
    print(f'We have logged in as {discordClient.user}')


@discordClient.event
async def on_message(message):
    if message.author == discordClient.user:
        return

    message_id = str(message.id)
    author_role = "assistant" if message.author == discordClient.user else "user"
    content = f"{message.author.display_name}: {message.content}"

    # Check if the message is a reply and if the replied-to message exists in the graph
    reply_to_id = None
    if message.reference and message.reference.message_id:
        reply_to_id = str(message.reference.message_id)
        if reply_to_id not in message_graph.messages:
            reply_to_id = None

    # Respond if the bot is mentioned or the message is a reply to the bot
    if (discordClient.user.mention in message.content or
            (message.reference and message.guild.get_member(
                message.reference.resolved.author.id) == discordClient.user)):
        if message.content == "":
            await message.reply("Oops your message got lost.")
            print("Empty message")
            return  # Don't send empty messages to the API
        # Add this message to the graph
        message_graph.add_message(message_id, author_role, content, message.created_at.timestamp(), reply_to=reply_to_id)
        response, error = await send_message(message_id)
        if error:
            await message.reply(error)
            return
        if response.tool_calls is not None:
            await process_tool_calls(message, response)
        else:
            sent_message = await message.reply(response.content)
            # Add the bot's response to the graph after sending it
            response_id = str(sent_message.id)
            message_graph.add_message(response_id, "assistant", response.content, time.time(), reply_to=message_id)


async def process_tool_calls(message, response):
    for tool_call in response.tool_calls:
        if tool_call.function.name == "python":
            command = tool_call.function.arguments

            # Check if command is a JSON string containing "command"
            try:
                parsed_command = json.loads(command)
                if "command" in parsed_command:
                    command = parsed_command["command"]
            except json.JSONDecodeError:
                # If command is not a JSON string, leave it as is
                pass

            tool_call_message = await message.reply(f"```python\n{command}```")
            response, error = execute_python(command)
            if error:
                error_message = await tool_call_message.reply(error)
                message_graph.add_message(str(error_message), "system", error, time.time(), reply_to=tool_call_message)
                return
            tool_response_message = await tool_call_message.reply("```" + response + "```")
            # add the tool call and the response to the graph
            message_graph.add_message(str(tool_call_message.id), "assistant", command,
                                      time.time(), reply_to=str(str(message.id)))
            message_graph.add_message(str(tool_response_message.id), "system", response, time.time(),
                                      reply_to=str(tool_call_message.id))


async def send_message(message_id):
    # Get the conversation chain
    message_chain = message_graph.get_message_chain(message_id)

    if len(message_chain) == 1:
        # add the initial prompt to the graph
        message_graph.add_message(message_id + "_system", "system", initial_prompt, time.time())
        # make sure the initial message had the initial prompt as a parent
        message_graph.messages[message_id].parent_id = message_id + "_system"
        # add the initial prompt to the message chain
        message_chain = message_graph.get_message_chain(message_id)

    # Send the conversation chain to the API
    try:
        completion = openAiClient.chat.completions.create(
            model=model,
            messages=message_chain,
            tools=tools,
            tool_choice="auto"
        )
        response = completion.choices[0].message

        return response, None
    except Exception as e:
        print(e)
        return None, "Error: " + str(e)


def execute_python(code):
    executor = DockerPythonExecutor()
    output, error = executor.run_code(code)
    return output, error


def save_message_graph():
    try:
        message_graph.save_messages()
        print("Message graph saved successfully.")
    except Exception as e:
        print(f"Error saving message graph: {e}")


# discordClient.run(discord_api_key)
atexit.register(save_message_graph)